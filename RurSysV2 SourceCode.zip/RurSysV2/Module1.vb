﻿Imports System.Windows.Forms

Module Module1

    Sub Main()
        Dim BenutzerEingabe As String

        Console.Beep()
        Console.WriteLine("
  __________                  _________                ____   ____________  
  \______   \ __ __ _______  /   _____/ ___.__.  ______\   \ /   /\_____  \ 
   |       _/|  |  \\_  __ \ \_____  \ <   |  | /  ___/ \   Y   /  /  ____/ 
   |    |   \|  |  / |  | \/ /        \ \___  | \___ \   \     /  /       \     Version 1.0
   |____|_  /|____/  |__|   /_______  / / ____|/____  >   \___/   \_______ \    by Einstellungen#0932
          \/                        \/  \/          \/                    \/    https://github.com/Rurso/RurSys
                    For educational purposes only ! 
")

        Console.WriteLine("Select a language. / Wählen Sie eine Sprache aus.
(1) English
(2) Deutsch")
        BenutzerEingabe = Console.ReadLine
        If BenutzerEingabe = 1 Then
            Console.WriteLine("(1) Show Current Network Info
(2) Show Device Info
(3) Shutdown PC")
            BenutzerEingabe = Console.ReadLine
            If BenutzerEingabe = "1" Then
                Console.WriteLine("Please enter the name of the W-lan Network you are currently connected to.")
                System.IO.File.WriteAllText(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & "RurSysV2Batch.bat", "netsh wlan show profiles " + Console.ReadLine + " key=clear
pause")
                System.Diagnostics.Process.Start(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & "RurSysV2Batch.bat")



            ElseIf BenutzerEingabe = "2" Then
                Console.WriteLine("Computer Name:" + My.Computer.Name)
                Console.WriteLine("OS Name: " + My.Computer.Info.OSFullName)
                Console.WriteLine("OS Platform: " + My.Computer.Info.OSPlatform)
                Console.WriteLine("OS Version:" + My.Computer.Info.OSVersion)
                Console.WriteLine("Memory (RAM): " + System.Math.Round(My.Computer.Info.TotalPhysicalMemory / (1024 * 1024 * 1024)).ToString + "gb")
                Console.WriteLine("Resolution (Main Monitor): " + Windows.Forms.SystemInformation.PrimaryMonitorSize.Width.ToString + " x " + Windows.Forms.SystemInformation.PrimaryMonitorSize.Height.ToString)
                Console.WriteLine("Maximized Window Size: " + Windows.Forms.SystemInformation.PrimaryMonitorMaximizedWindowSize.Width.ToString + " x " + Windows.Forms.SystemInformation.PrimaryMonitorMaximizedWindowSize.Width.ToString)
                Console.WriteLine("(1) Back
(2) Quit")
                BenutzerEingabe = Console.ReadLine
                If BenutzerEingabe = "1" Then
                    Application.Restart()
                    Return
                ElseIf BenutzerEingabe = "2" Then
                    Return
                End If



            ElseIf BenutzerEingabe = "3" Then
                Console.WriteLine("(1) Shutdown PC
(2) Loop Shutdown PC (needs Adminstrator Permissions")
                BenutzerEingabe = Console.ReadLine
                If BenutzerEingabe = "1" Then
                    System.IO.File.WriteAllText(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & "RurSysV2Batch.bat", "shutdown -s -f -t 0 -y")
                    System.Diagnostics.Process.Start(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & "RurSysV2Batch.bat")
                ElseIf BenutzerEingabe = "2" Then
                    Console.WriteLine("(1) Now
(2) At next System Boot")
                    BenutzerEingabe = Console.ReadLine
                    If BenutzerEingabe = "1" Then
                        System.IO.File.WriteAllText("C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup" & "\" & "RurSysV2Batch.bat", "shutdown -s -f -t 0 -y")
                        System.Diagnostics.Process.Start("C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup" & "\" & "RurSysV2Batch.bat")
                    ElseIf BenutzerEingabe = "2" Then
                        System.IO.File.WriteAllText("C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup" & "\" & "RurSysV2Batch.bat", "shutdown -s -f -t 0 -y")
                    End If
                End If
            End If



        ElseIf BenutzerEingabe = 2 Then
            Console.WriteLine("(1) Zeige Informationen über das momentan verbundene Netzwerk an.
(2) Zeige PC Informationen an
(3) Fahre den Computer runter")
            BenutzerEingabe = Console.ReadLine
            If BenutzerEingabe = "1" Then
                Console.WriteLine("Bitte geben Sie an wie der Name des Netzwerkes heißt mit dem sie momentan verbunden sind.")
                System.IO.File.WriteAllText(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & "RurSysV2Batch.bat", "netsh wlan show profiles " + Console.ReadLine + " key=clear
pause")
                System.Diagnostics.Process.Start(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & "RurSysV2Batch.bat")
            ElseIf BenutzerEingabe = "2" Then
                Console.WriteLine("Computer Name:" + My.Computer.Name)
                Console.WriteLine("OS Name: " + My.Computer.Info.OSFullName)
                Console.WriteLine("OS Platform: " + My.Computer.Info.OSPlatform)
                Console.WriteLine("OS Version:" + My.Computer.Info.OSVersion)
                Console.WriteLine("Memory (RAM): " + System.Math.Round(My.Computer.Info.TotalPhysicalMemory / (1024 * 1024 * 1024)).ToString + "gb")
                Console.WriteLine("Resolution (Main Monitor): " + Windows.Forms.SystemInformation.PrimaryMonitorSize.Width.ToString + " x " + Windows.Forms.SystemInformation.PrimaryMonitorSize.Height.ToString)
                Console.WriteLine("Maximized Window Size: " + Windows.Forms.SystemInformation.PrimaryMonitorMaximizedWindowSize.Width.ToString + " x " + Windows.Forms.SystemInformation.PrimaryMonitorMaximizedWindowSize.Width.ToString)
                Console.WriteLine("(1) Zurück
(2) Verlassen")
                BenutzerEingabe = Console.ReadLine
                If BenutzerEingabe = "1" Then
                    Application.Restart()
                    Return
                ElseIf BenutzerEingabe = "2" Then
                    Return
                End If


            ElseIf BenutzerEingabe = "3" Then
                Console.WriteLine("(1) Fahre den Computer runter
(2) Fahre den Computer wiederhohlend runter (braucht Adminstrator Rechte)")
                BenutzerEingabe = Console.ReadLine
                If BenutzerEingabe = "1" Then
                    System.IO.File.WriteAllText(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & "RurSysV2Batch.bat", "shutdown -s -f -t 0 -y")
                    System.Diagnostics.Process.Start(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & "RurSysV2Batch.bat")
                ElseIf BenutzerEingabe = "2" Then
                    Console.WriteLine("(1) Jetzt
(2) Beim nähsten Computer start")
                    BenutzerEingabe = Console.ReadLine
                    If BenutzerEingabe = "1" Then
                        System.IO.File.WriteAllText("C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup" & "\" & "RurSysV2Batch.bat", "shutdown -s -f -t 0 -y")
                        System.Diagnostics.Process.Start("C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup" & "\" & "RurSysV2Batch.bat")
                    ElseIf BenutzerEingabe = "2" Then
                        System.IO.File.WriteAllText("C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup" & "\" & "RurSysV2Batch.bat", "shutdown -s -f -t 0 -y")
                    End If
                End If
            End If
        End If
        Console.Beep()
        System.Threading.Thread.Sleep(1)
        Console.Beep()
        Application.Restart()
        Return
    End Sub

End Module





